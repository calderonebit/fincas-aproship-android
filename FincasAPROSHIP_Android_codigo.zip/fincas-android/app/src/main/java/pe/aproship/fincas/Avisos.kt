package pe.aproship.fincas

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.job.JobInfo
import android.app.job.JobScheduler
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Avisos en el teléfono: guarda el vínculo con la cuenta, consulta el servidor y muestra las notificaciones. */
object Avisos {
    private const val CANAL = "avisos"
    private const val JOB_ID = 2601
    private const val NOTIF_RESUMEN = 1

    fun prefs(c: Context): SharedPreferences = c.getSharedPreferences("fincas", Context.MODE_PRIVATE)

    fun vincular(c: Context, token: String, usuario: Int, servidor: String) {
        prefs(c).edit()
            .putString("token", token).putInt("usuario", usuario).putString("servidor", servidor)
            .remove("vistos").remove("resumen_dia").apply()
        programar(c)
        Thread { revisar(c) }.start()
    }

    fun desvincular(c: Context) {
        prefs(c).edit().remove("token").remove("usuario").remove("vistos").remove("resumen_dia").apply()
        (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancelAll()
    }

    fun vinculado(c: Context, usuario: Int): Boolean =
        prefs(c).getString("token", null) != null && prefs(c).getInt("usuario", -1) == usuario

    /** Revisión cada hora (Android puede agruparla para ahorrar batería), solo con internet, y se mantiene al reiniciar. */
    fun programar(c: Context) {
        if (prefs(c).getString("token", null) == null) return
        val js = c.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
        if (js.allPendingJobs.any { it.id == JOB_ID }) return
        js.schedule(
            JobInfo.Builder(JOB_ID, ComponentName(c, AvisosJob::class.java))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPeriodic(60 * 60 * 1000L, 20 * 60 * 1000L)
                .setPersisted(true)
                .build()
        )
    }

    fun crearCanal(c: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val ch = NotificationChannel(CANAL, c.getString(R.string.canal_avisos), NotificationManager.IMPORTANCE_DEFAULT)
        ch.description = c.getString(R.string.canal_avisos_desc)
        ch.enableLights(true)
        ch.lightColor = 0xFFDCBF6B.toInt()
        (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
    }

    /** Consulta /api/avisos_app y avisa solo lo nuevo. Devuelve false si hubo un error de red (para reintentar). */
    fun revisar(c: Context): Boolean {
        val p = prefs(c)
        val token = p.getString("token", null) ?: return true
        val servidor = p.getString("servidor", BuildConfig.SERVIDOR) ?: BuildConfig.SERVIDOR
        val con = (URL("$servidor/api/avisos_app").openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000; readTimeout = 20000
            setRequestProperty("X-Token", token)
            setRequestProperty("Accept", "application/json")
        }
        return try {
            val codigo = con.responseCode
            if (codigo == 401) { desvincular(c); return true }
            if (codigo != 200) return false
            val datos = JSONObject(con.inputStream.bufferedReader().use { it.readText() }).getJSONObject("datos")
            mostrar(c, datos)
            true
        } catch (e: Exception) {
            false
        } finally {
            con.disconnect()
        }
    }

    private class Aviso(val id: Int, val titulo: String, val lugar: String, val dias: Int, val detalle: String, val enlace: String)

    private fun mostrar(c: Context, datos: JSONObject) {
        val p = prefs(c)
        val lista = datos.getJSONArray("avisos")
        val avisos = (0 until lista.length()).map { i ->
            val a = lista.getJSONObject(i)
            Aviso(a.getInt("id"), a.getString("titulo"), a.optString("lugar"), a.getInt("dias"), a.optString("detalle"), a.optString("enlace", "/"))
        }
        val hoy = datos.getString("hoy")
        // "id:dias" para volver a avisar cuando un aviso de mañana pasa a ser de hoy o se vence
        val claves = avisos.associateBy { "${it.id}:${if (it.dias < 0) "v" else it.dias}" }
        val vistos = p.getStringSet("vistos", emptySet()) ?: emptySet()
        val nuevos = claves.filterKeys { it !in vistos }.values.toList()
        val primerResumenDelDia = p.getString("resumen_dia", "") != hoy && avisos.isNotEmpty()

        p.edit().putStringSet("vistos", claves.keys).apply()
        if (nuevos.isEmpty() && !primerResumenDelDia) return
        if (primerResumenDelDia) p.edit().putString("resumen_dia", hoy).apply()

        crearCanal(c)
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 33 && !nm.areNotificationsEnabled()) return

        val mostrarLista = if (primerResumenDelDia) avisos else nuevos
        if (mostrarLista.size == 1) {
            val a = mostrarLista[0]
            nm.notify(a.id + 100, base(c, a.enlace)
                .setContentTitle(cuando(a.dias) + ": " + a.titulo)
                .setContentText(a.lugar)
                .setStyle(Notification.BigTextStyle().bigText(a.lugar + if (a.detalle.isNotBlank()) "\n" + a.detalle else ""))
                .build())
            return
        }
        val vencidas = mostrarLista.count { it.dias < 0 }
        val titulo = "${mostrarLista.size} labores por hacer" + if (vencidas > 0) " · $vencidas vencidas" else ""
        val estilo = Notification.InboxStyle().setBigContentTitle(titulo)
        mostrarLista.take(6).forEach { estilo.addLine(cuando(it.dias) + ": " + it.titulo + " · " + it.lugar) }
        if (mostrarLista.size > 6) estilo.setSummaryText("y ${mostrarLista.size - 6} más")
        nm.notify(NOTIF_RESUMEN, base(c, "/")
            .setContentTitle(titulo)
            .setContentText(mostrarLista.first().titulo + if (mostrarLista.size > 1) " y otras" else "")
            .setStyle(estilo)
            .setNumber(mostrarLista.size)
            .build())
    }

    private fun cuando(dias: Int) = when {
        dias < -1 -> "Vencida hace ${-dias} días"
        dias == -1 -> "Vencida ayer"
        dias == 0 -> "Hoy"
        else -> "Mañana"
    }

    private fun base(c: Context, enlace: String): Notification.Builder {
        val abrir = Intent(c, MainActivity::class.java)
            .putExtra("ruta", enlace)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pi = PendingIntent.getActivity(c, enlace.hashCode(), abrir, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        @Suppress("DEPRECATION")
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(c, CANAL) else Notification.Builder(c).setDefaults(Notification.DEFAULT_ALL)
        return b.setSmallIcon(R.drawable.ic_aviso)
            .setColor(0xFF1F3B1B.toInt())
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setCategory(Notification.CATEGORY_REMINDER)
    }
}
