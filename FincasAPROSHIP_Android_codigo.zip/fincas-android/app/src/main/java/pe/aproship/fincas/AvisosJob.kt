package pe.aproship.fincas

import android.app.job.JobParameters
import android.app.job.JobService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Tarea en segundo plano: revisa los avisos aunque la app esté cerrada. */
class AvisosJob : JobService() {
    override fun onStartJob(params: JobParameters): Boolean {
        Thread {
            try { Sincronizar.subir(applicationContext) } catch (e: Exception) {}   // de paso, sube lo hecho sin señal
            val ok = Avisos.revisar(applicationContext)
            jobFinished(params, !ok)   // si no hubo red, Android lo reintenta más tarde
        }.start()
        return true
    }

    override fun onStopJob(params: JobParameters): Boolean = true
}

/** Al reiniciar el teléfono o actualizar la app, vuelve a programar la revisión. */
class Arranque : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Avisos.programar(c)
        Sincronizar.programar(c)
    }
}
