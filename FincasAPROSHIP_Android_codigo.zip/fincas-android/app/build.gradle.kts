import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Firma: datos en firma.properties (no se sube al repositorio) o en variables de entorno del CI
val firma = Properties().apply {
    val f = rootProject.file("firma.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
fun dato(k: String): String? = firma.getProperty(k) ?: System.getenv(k.uppercase().replace('.', '_'))

android {
    namespace = "pe.aproship.fincas"
    compileSdk = 34

    defaultConfig {
        applicationId = "pe.aproship.fincas"
        minSdk = 24
        targetSdk = 34
        versionCode = (System.getenv("VERSION_CODE") ?: "1").toInt()
        versionName = "1.0." + (System.getenv("VERSION_CODE") ?: "0")
        buildConfigField("String", "SERVIDOR", "\"https://fincas.aproship.com\"")
    }

    signingConfigs {
        create("aproship") {
            val ruta = dato("firma.archivo")
            if (ruta != null) {
                storeFile = rootProject.file(ruta)
                storePassword = dato("firma.clave")
                keyAlias = dato("firma.alias") ?: "aproship"
                keyPassword = dato("firma.clave")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            if (dato("firma.archivo") != null) signingConfig = signingConfigs.getByName("aproship")
        }
    }
    buildFeatures { buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
