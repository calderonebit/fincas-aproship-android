# El puente con la página web se llama desde JavaScript: no renombrar sus métodos
-keepclassmembers class pe.aproship.fincas.MainActivity$PuenteWeb {
    @android.webkit.JavascriptInterface <methods>;
}
